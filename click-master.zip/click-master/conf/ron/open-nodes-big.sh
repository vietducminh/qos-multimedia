rxvt -title mediaone-ma -g 80x8+0+0 -e ssh -l ron mediaone-ma.ron &
rxvt -title utah -g 80x8+0+130 -e ssh -l ron utah.ron &
##rxvt -title sightpath -g 80x8+0+260 -e ssh -l ron sightpath.ron &
rxvt -title ccicom -g 80x8+0+390 -e ssh -l ron ccicom.ron &
rxvt -title cornell -g 80x8+0+520 -e ssh -l ron cornell.ron &
rxvt -title msanders -g 80x8+0+650 -e ssh -l ron msanders.ron &
rxvt -title aros -g 80x8+0+780 -e ssh -l ron aros.ron &
#rxvt -title nyu -g 80x8+0+910 -e ssh -l ron nyu.ron &
rxvt -title nyu -g 80x8+0+260 -e ssh -l ron nyu.ron &



rxvt -title mit -g 80x8+505+0 -e ssh -l ron mit.ron &
#rxvt -title nl -g 80x8+505+130 -e ssh -l ron nl.ron &
rxvt -title cmu -g 80x8+505+260 -e ssh -l ron cmu.ron &
##rxvt -title lulea -g 80x8+505+390 -e ssh -l ron lulea.ron &
##rxvt -title stoller -g 80x8+505+520 -e ssh -l ron stoller.ron &
rxvt -title mazu1 -g 80x8+505+650 -e ssh -l ron mazu1.ron &
rxvt -title pdi -g 80x8+505+780 -e ssh -l ron pdi.ron &
#rxvt -title nc -g 80x8+505+910 -e ssh -l ron nc.ron &
#rxvt -title nc -g 80x8+505+520 -e ssh -l ron nc.ron &
#rxvt -title kr -g 80x8+505+1040 -e ssh -l ron kr.ron &
rxvt -title kr -g 80x8+505+390 -e ssh -l ron kr.ron &
